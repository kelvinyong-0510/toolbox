// content.js
const sidebarId = 'my-extension-sidebar';

// Check if the sidebar is already present
if (!document.getElementById(sidebarId)) {
  // Create the sidebar container
  const sidebar = document.createElement('div');
  sidebar.id = sidebarId;
  sidebar.innerHTML = 'Loading...'; // Placeholder content
  // Add styles or load an external CSS file
  sidebar.style.cssText = `
    position: fixed;
    top: 0;
    right: 0;
    width: 300px; /* Adjust the width as needed /
    height: 100%;
    background-color: white;
    box-shadow: -2px 0 5px rgba(0, 0, 0, 0.2);
    padding: 10px;
    z-index: 10000; / Ensure the sidebar is above other content /
    overflow-y: auto; / Add scroll if the content overflows /
    display: none; / Start with sidebar hidden */
    `;
    
    // Append the sidebar to the body of the page
    document.body.appendChild(sidebar);
    }
    
    // Function to toggle the sidebar visibility
    function toggleSidebar() {
    const sidebar = document.getElementById(sidebarId);
    if (sidebar.style.display === 'none') {
    sidebar.style.display = 'block';
    } else {
    sidebar.style.display = 'none';
    }
    }
    
    // Listen for messages from the popup or background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message === 'toggleSidebar') {
    toggleSidebar();
    }
    });
