document.addEventListener('DOMContentLoaded', () => {
  const input   = document.getElementById('skuInput');
  const results = document.getElementById('results');
  let inventory = [];

  // Load data from Cloudflare
  fetch('https://toolbox.mipos.me/api/tutorial-data.json')
    .then(r => r.json())
    .then(json => inventory = json)
    .catch(console.error);

  function render() {
    const term = input.value.trim().toLowerCase();
    results.innerHTML = '';
    if (!term) return;

    const matches = inventory.filter(item => {
      return item.SKU.toLowerCase().includes(term)
        || item.PlaylistName.toLowerCase().includes(term)
        || (item.VideoLinks || []).some(v => v.title.toLowerCase().includes(term))
        || (item.FileLinks  || []).some(f => f.name.toLowerCase().includes(term))
        || (item.FileLinks  || []).some(f => (f.description||'').toLowerCase().includes(term));
    });

    if (!matches.length) {
      results.innerHTML = `<li class="result-item no-results">No results for “${input.value}”</li>`;
      return;
    }

    matches.forEach(item => {
      // Playlist
      if (item.PlaylistLink) {
        const pl = document.createElement('li');
        pl.className = 'result-item playlist-item';
        pl.innerHTML = `
          <div class="result-header">
            <span class="playlist-title">Playlist: ${item.PlaylistName}</span>
            <button class="copy-btn">📋</button>
          </div>`;
        const btn = pl.querySelector('.copy-btn');
        pl.onclick = () => {
          navigator.clipboard.writeText(`${item.PlaylistName} → ${item.PlaylistLink}`);
          btn.textContent = '✔';
          setTimeout(() => btn.textContent = '📋', 1000);
        };
        results.appendChild(pl);
      }

      // Videos
      (item.VideoLinks || []).forEach(video => {
        if (!video.title.toLowerCase().includes(term)) return;
        const li = document.createElement('li');
        li.className = 'result-item';
        li.innerHTML = `
          <span class="video-title">${video.title}</span>
          <button class="copy-btn">📋</button>
        `;
        const btn = li.querySelector('.copy-btn');
        li.onclick = () => {
          navigator.clipboard.writeText(`${video.title} → ${video.link}`);
          btn.textContent = '✔';
          setTimeout(() => btn.textContent = '📋', 1000);
        };
        results.appendChild(li);
      });

      // Files (two-line entries)
      const files = (item.FileLinks || [])
        .filter(f => f.name.toLowerCase().includes(term) 
                  || (f.description||'').toLowerCase().includes(term));
      if (files.length) {
        // Header
        const header = document.createElement('li');
        header.className = 'file-header';
        header.textContent = 'Files';
        results.appendChild(header);

        files.forEach(file => {
          const li = document.createElement('li');
          li.className = 'file-item';
          li.innerHTML = `
            <div class="file-content">
              <div class="file-name">${file.name}</div>
              <div class="file-desc">${file.description || ''}</div>
            </div>
            <div class="file-btns">
              <button class="copy-btn">📋</button>
              <button class="download-btn">⬇️</button>
            </div>
          `;
          const [copyBtn, dlBtn] = li.querySelectorAll('button');
          copyBtn.onclick = e => {
            e.stopPropagation();
            navigator.clipboard.writeText(file.link);
            copyBtn.textContent = '✔';
            setTimeout(() => copyBtn.textContent = '📋', 1000);
          };
          dlBtn.onclick = e => {
            e.stopPropagation();
            window.open(file.link, '_blank');
          };
          results.appendChild(li);
        });
      }
    });
  }

  input.addEventListener('input', render);
});
