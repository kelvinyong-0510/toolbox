// Function to normalize size by removing decimal places
function normalizeSize(size) {
    return size.replace(/\.0+/g, ''); // Remove any ".0" occurrences
}

// Function to load the JSON data from Cloudflare
function loadJSON(callback) {
    fetch('https://toolbox.mipos.me/api/led-data.json')
        .then(response => response.json())
        .then(data => callback(data))
        .catch(error => console.error('Error loading data:', error));
}

// Event listener for real-time input in the text field
document.getElementById('skuInput').addEventListener('input', function(event) {
    var searchInput = normalizeSize(event.target.value.trim().toLowerCase()); // Normalize search input
    
    loadJSON(function(data) {
        // Filter results based on the search input
        var results = [];
        
        // Search for both SKU and Size matches
        data.forEach(item => {
            item.Details.forEach(detail => {
                var normalizedSize = normalizeSize(detail.Size.toLowerCase()); // Normalize the size for comparison
                
                if (normalizedSize.includes(searchInput) || item.SKU.toLowerCase().includes(searchInput)) {
                    // If the size or SKU matches, add the item to the results
                    results.push({ sku: item.SKU, ...detail });
                }
            });
        });

        // Display the results dynamically as the user types
        if (results.length > 0) {
            displayResults(results);
        } else {
            document.getElementById('results').innerText = 'No results found.';
        }
    });
});

// Function to display results (unchanged)
function displayResults(matches) {
    var resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = ''; // Clear previous results

    matches.forEach(match => {
        var resultCard = document.createElement('div');
        resultCard.className = 'result-card';

        // Display SKU (board name) with the size
        var skuHeader = document.createElement('div');
        skuHeader.className = 'sku-header';
        skuHeader.textContent = `SKU: ${match.sku}`;

        var sizeHeader = document.createElement('div');
        sizeHeader.className = 'size-header';
        sizeHeader.textContent = `Size: ${match.Size}`;
        
        var posterSizeText = document.createElement('div');
        posterSizeText.className = 'result-text';
        posterSizeText.textContent = `- Poster Size [TO PRINT]: ${match.PosterSize}`;
        
        var displaySizeText = document.createElement('div');
        displaySizeText.className = 'result-text';
        displaySizeText.textContent = `- Display Size: ${match.DisplaySize}`;

        var copyIcon = document.createElement('span'); // Icon for copy to clipboard
        copyIcon.className = 'copy-icon';
        copyIcon.textContent = '\u{1F4CB}'; //📋 
        copyIcon.title = 'Copy to clipboard'; // Tooltip message

        // Append elements to the result card
        resultCard.appendChild(skuHeader); // Add SKU (board name)
        resultCard.appendChild(sizeHeader);
        resultCard.appendChild(posterSizeText);
        resultCard.appendChild(displaySizeText);
        resultCard.appendChild(copyIcon);

        // Append the result card to the results container
        resultsDiv.appendChild(resultCard);

        // Click event for the copy functionality
        copyIcon.addEventListener('click', function(event) {
            event.stopPropagation(); // Prevent triggering click events on parent elements
            var textToCopy = `SKU: ${match.sku}\nSize: ${match.Size}\nPoster Size: ${match.PosterSize}\nDisplay Size: ${match.DisplaySize}`;
            navigator.clipboard.writeText(textToCopy).then(() => {
                // Update the icon or text to indicate the copy action was successful
                copyIcon.textContent = '\u{2705}';//✅  or your original text/icon
                // Optionally reset the icon or text after a delay
                setTimeout(() => {   
                    copyIcon.textContent = '\u{1F4CB}'; //📋
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
            });
        });
    });
}

// Reset button functionality to clear input and results
document.getElementById('resetButton').addEventListener('click', function() {
    document.getElementById('skuInput').value = ''; // Clear the input field
    document.getElementById('results').innerHTML = ''; // Clear the results
});
